// swiper/bundle@11.2.2 downloaded from https://ga.jspm.io/npm:swiper@11.2.2/swiper-bundle.mjs

import{S as s}from"./_/CGpNtTMN.js";import{V as a,K as o,M as r,N as t,P as m,S as i,a as j,Z as p,C as e,A as f,H as _,b as c,c as d,T as u,f as S,G as b,d as g,E as h,e as l,g as n,h as x,i as A,j as C}from"./_/BLZbtAzk.js";import"./_/BL9Wmvfp.js";import"./_/AW-233Sq.js";const E=[a,o,r,t,m,i,j,p,e,f,_,c,d,u,S,b,g,h,l,n,x,A,C];s.use(E);export{s as Swiper,s as default};

